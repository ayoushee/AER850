# Integer (int) data type
age = 25
print("Age:", age)
print("Data type:", type(age))

# String data type
name = "John Doe"
print("Name:", name)
print("Data type:", type(name))

# Double precision float (float) data type
distance = 1234.56789
print("Distance:", distance)
print("Data type:", type(distance))